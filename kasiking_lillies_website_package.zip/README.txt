KASIKING & LILLIES CREATIVE BRANDS HUB PVT LTD
Personalised website package

BUSINESS DETAILS INCLUDED
- Phone / WhatsApp: +263 77 660 4821
- Email: klcreativebrandshub@gmail.com
- Location: Harare, Zimbabwe
- Services highlighted: branding, graphic design, packaging and labels, perfume branding, digital marketing
- Goal: attract customers and showcase/sell business offerings (online checkout is not yet configured)
- Publishing preference: free hosting first

HOW TO PREVIEW
Open kasiking_lillies_website.html in a modern web browser. The website is responsive for phones and computers.

BEFORE / WHEN PUBLISHING
1. The contact form opens the visitor's email application with the enquiry drafted. It does not store submissions or send automatically.
2. Free hosting options include GitHub Pages or Netlify's free tier. You will need to create/sign into your chosen account and upload/publish the site.
3. A custom domain is optional and may cost money.
4. The current portfolio panels are clearly concept-style placeholders; replace them with genuine project images when available.
5. A product checkout/payment system is not configured. This version is a professional business and enquiry website, not a functioning online store.
